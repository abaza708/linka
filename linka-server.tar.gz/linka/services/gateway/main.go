package main

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/gorilla/websocket"
	"github.com/redis/go-redis/v9"

	"linka/internal/auth"
	"linka/internal/db"
	"linka/internal/otp"
	"linka/internal/push"
	"linka/internal/rate"
	"linka/internal/sms"
	"linka/internal/storage"
	"linka/internal/ws"
)

type App struct {
	DB           *db.DB
	RDB          *redis.Client
	JWT          auth.JWT
	Hub          *ws.Hub
	S3           *storage.S3
	Limiter      rate.Limiter
	Twilio       sms.Twilio
	CDNBase      string
	VAPIDPublic  string
	VAPIDPrivate string
	VAPIDSubject string
	FCMKey       string
	AppBaseURL   string
}

type User struct {
	ID          string    `json:"id"`
	Email       *string   `json:"email,omitempty"`
	Phone       *string   `json:"phone,omitempty"`
	Username    *string   `json:"username,omitempty"`
	DisplayName *string   `json:"display_name,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
}

type SignupReq struct {
	Email       *string `json:"email"`
	Phone       *string `json:"phone"`
	Username    *string `json:"username"`
	DisplayName *string `json:"display_name"`
	Password    string  `json:"password"`
}

type LoginReq struct {
	Identifier string `json:"identifier"`
	Password   string `json:"password"`
}

type TokenResp struct {
	Token string `json:"token"`
	User  User   `json:"user"`
}

type Attachment struct {
	Key         string `json:"key"`
	URL         string `json:"url"`
	ContentType string `json:"content_type"`
	Size        int64  `json:"size"`
}

type SendMessageReq struct {
	ToUserID    string          `json:"to_user_id"`
	ChatID      string          `json:"chat_id"`
	Type        string          `json:"type"`
	Content     json.RawMessage `json:"content"`
	Attachments []Attachment    `json:"attachments"`
}

type MessageResp struct {
	ID          int64        `json:"id"`
	ChatID      string       `json:"chat_id"`
	SenderID    string       `json:"sender_id"`
	Payload     any          `json:"payload"`
	Attachments []Attachment `json:"attachments"`
	CreatedAt   time.Time    `json:"created_at"`
}

type OTPRequest struct {
	Phone string `json:"phone"`
}

type OTPVerify struct {
	Phone string `json:"phone"`
	Code  string `json:"code"`
}

type UploadInitReq struct {
	Filename    string `json:"filename"`
	ContentType string `json:"content_type"`
}

type UploadInitResp struct {
	URL       string `json:"url"`
	ObjectKey string `json:"object_key"`
	Method    string `json:"method"`
	ExpiresIn int    `json:"expires_in"`
	PublicURL string `json:"public_url"`
}

type wsConn struct{ c *websocket.Conn }

func (w *wsConn) Send(b []byte) error { return w.c.WriteMessage(websocket.TextMessage, b) }
func (w *wsConn) Close() error        { return w.c.Close() }

var upgrader = websocket.Upgrader{CheckOrigin: func(r *http.Request) bool { return true }}

func main() {
	dsn := env("DATABASE_URL", "postgres://postgres:postgres@postgres:5432/linka?sslmode=disable")
	redisAddr := env("REDIS_ADDR", "redis:6379")
	redisPass := env("REDIS_PASSWORD", "")
	jwtSecret := env("JWT_SECRET", "devsecret")
	addr := env("HTTP_ADDR", ":8080")
	minioEndpoint := env("MINIO_ENDPOINT", "minio:9000")
	minioAccess := env("MINIO_ACCESS_KEY", env("MINIO_ROOT_USER", "minioadmin"))
	minioSecret := env("MINIO_SECRET_KEY", env("MINIO_ROOT_PASSWORD", "minioadmin"))
	minioSecure := env("MINIO_SECURE", "false") == "true"
	minioBucket := env("MINIO_BUCKET", "linka")
	cdnBase := env("CDN_BASE", "")
	twSid := env("TWILIO_ACCOUNT_SID", "")
	twTok := env("TWILIO_AUTH_TOKEN", "")
	twFrom := env("TWILIO_FROM_NUMBER", "")
	vapidPub := env("VAPID_PUBLIC_KEY", "")
	vapidPriv := env("VAPID_PRIVATE_KEY", "")
	vapidSubj := env("VAPID_SUBJECT", "mailto:admin@localhost")
	fcmKey := env("FCM_SERVER_KEY", "")
	appBase := env("APP_BASE_URL", "")

	database, err := db.Connect(dsn)
	if err != nil {
		log.Fatal(err)
	}
	defer database.Close()
	ctx := context.Background()
	if err := database.Migrate(ctx); err != nil {
		log.Fatal(err)
	}

	rdb := redis.NewClient(&redis.Options{Addr: redisAddr, Password: redisPass, DB: 0})
	if err := rdb.Ping(ctx).Err(); err != nil {
		log.Fatal(err)
	}

	s3, err := storage.Connect(minioEndpoint, minioAccess, minioSecret, minioSecure, minioBucket)
	if err != nil {
		log.Fatal(err)
	}

	app := &App{DB: database, RDB: rdb, JWT: auth.JWT{Secret: []byte(jwtSecret), TTL: 24 * time.Hour}, Hub: ws.NewHub(), S3: s3, Limiter: rate.Limiter{RDB: rdb}, Twilio: sms.Twilio{AccountSID: twSid, AuthToken: twTok, From: twFrom}, CDNBase: cdnBase, VAPIDPublic: vapidPub, VAPIDPrivate: vapidPriv, VAPIDSubject: vapidSubj, FCMKey: fcmKey, AppBaseURL: appBase}

	http.HandleFunc("/v1/auth/signup", withCORS(app.handleSignup))
	http.HandleFunc("/v1/auth/login", withCORS(app.handleLogin))
	http.HandleFunc("/v1/auth/request_otp", withCORS(app.handleRequestOTP))
	http.HandleFunc("/v1/auth/verify_otp", withCORS(app.handleVerifyOTP))
	http.HandleFunc("/v1/files/upload/init", withCORS(app.authMiddleware(app.handleUploadInit)))
	http.HandleFunc("/v1/messages/send", withCORS(app.authMiddleware(app.handleSendMessage)))
	http.HandleFunc("/v1/messages/with/", withCORS(app.authMiddleware(app.handleGetWithUser)))
	http.HandleFunc("/v1/search", withCORS(app.authMiddleware(app.handleSearch)))
	http.HandleFunc("/v1/users/search", withCORS(app.authMiddleware(app.handleUsersSearch)))
	http.HandleFunc("/v1/status/create", withCORS(app.authMiddleware(app.handleCreateStatus)))
	http.HandleFunc("/v1/status/feed", withCORS(app.authMiddleware(app.handleStatusFeed)))
	http.HandleFunc("/v1/status/view/", withCORS(app.authMiddleware(app.handleStatusView)))
	http.HandleFunc("/v1/e2e/register", withCORS(app.authMiddleware(app.handleE2ERegister)))
	http.HandleFunc("/v1/e2e/bundle/", withCORS(app.authMiddleware(app.handleE2EBundle)))
	http.HandleFunc("/v1/push/vapid-public-key", withCORS(app.handleVAPIDPublic))
	http.HandleFunc("/v1/push/register/web", withCORS(app.authMiddleware(app.handleRegisterWebPush)))
	http.HandleFunc("/v1/push/register/fcm", withCORS(app.authMiddleware(app.handleRegisterFCM)))
	http.HandleFunc("/v1/push/test", withCORS(app.authMiddleware(app.handlePushTest)))
	http.HandleFunc("/v1/chats", withCORS(app.authMiddleware(app.handleChatsList)))
	http.HandleFunc("/v1/chats/create", withCORS(app.authMiddleware(app.handleCreateChat)))
	http.HandleFunc("/v1/chats/", withCORS(app.authMiddleware(app.handleChatMux)))
	http.HandleFunc("/v1/messages/", withCORS(app.authMiddleware(app.handleMessagesByChat)))
	http.HandleFunc("/v1/messages/react/", withCORS(app.authMiddleware(app.handleReact)))
	http.HandleFunc("/v1/messages/forward/", withCORS(app.authMiddleware(app.handleForward)))
	http.HandleFunc("/v1/reactions", withCORS(app.authMiddleware(app.handleReactionsForChat)))
	http.HandleFunc("/v1/invites/", withCORS(app.authMiddleware(app.handleInviteMux)))
	http.HandleFunc("/ws", app.handleWS)

	log.Println("listening", addr)
	log.Fatal(http.ListenAndServe(addr, nil))
}

func env(k, d string) string {
	v := os.Getenv(k)
	if v == "" {
		return d
	}
	return v
}

func withCORS(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Headers", "Authorization, Content-Type")
		w.Header().Set("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
		w.Header().Set("Access-Control-Expose-Headers", "X-Chat-ID")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusOK)
			return
		}
		next.ServeHTTP(w, r)
	}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func (a *App) handleSignup(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	var req SignupReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if req.Password == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if (req.Email == nil || *req.Email == "") && (req.Phone == nil || *req.Phone == "") && (req.Username == nil || *req.Username == "") {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if req.Username != nil {
		u := strings.TrimSpace(*req.Username)
		req.Username = &u
	}
	hash, err := auth.HashPassword(req.Password)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	var u User
	err = a.DB.SQL.QueryRowContext(r.Context(),
		"insert into users(email, phone, username, display_name, password_hash) values($1,$2,$3,$4,$5) returning id, email, phone, username, display_name, created_at",
		req.Email, req.Phone, req.Username, req.DisplayName, hash,
	).Scan(&u.ID, &u.Email, &u.Phone, &u.Username, &u.DisplayName, &u.CreatedAt)
	if err != nil {
		w.WriteHeader(http.StatusConflict)
		return
	}
	tok, err := a.JWT.Sign(u.ID)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	writeJSON(w, http.StatusOK, TokenResp{Token: tok, User: u})
}

func (a *App) handleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	var req LoginReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	var u User
	var hash string
	q := "select id, email, phone, username, display_name, created_at, password_hash from users where email=$1 or username=$1 or phone=$1 limit 1"
	err := a.DB.SQL.QueryRowContext(r.Context(), q, req.Identifier).Scan(&u.ID, &u.Email, &u.Phone, &u.Username, &u.DisplayName, &u.CreatedAt, &hash)
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	if !auth.CheckPassword(hash, req.Password) {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	tok, err := a.JWT.Sign(u.ID)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	writeJSON(w, http.StatusOK, TokenResp{Token: tok, User: u})
}

func (a *App) handleRequestOTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	var req OTPRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if req.Phone == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	ip := r.Header.Get("X-Forwarded-For")
	if ip == "" {
		ip = strings.Split(r.RemoteAddr, ":")[0]
	}
	if !a.Limiter.Allow(r.Context(), "rl:otp:ip:"+ip, 20, time.Hour) {
		w.WriteHeader(http.StatusTooManyRequests)
		return
	}
	if !a.Limiter.Allow(r.Context(), "rl:otp:ph:"+req.Phone, 5, time.Hour) {
		w.WriteHeader(http.StatusTooManyRequests)
		return
	}
	code := otp.Code6()
	a.RDB.Set(r.Context(), "otp:ph:"+req.Phone, code, 5*time.Minute)
	_ = a.Twilio.SendSMS(req.Phone, "Your Linka code: "+code)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *App) handleVerifyOTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	var req OTPVerify
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if req.Phone == "" || req.Code == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	val, err := a.RDB.Get(r.Context(), "otp:ph:"+req.Phone).Result()
	if err != nil || val != req.Code {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	var u User
	scanErr := a.DB.SQL.QueryRowContext(r.Context(), "select id, email, phone, username, display_name, created_at from users where phone=$1 limit 1", req.Phone).Scan(&u.ID, &u.Email, &u.Phone, &u.Username, &u.DisplayName, &u.CreatedAt)
	switch scanErr {
	case nil:
		break
	case sql.ErrNoRows:
		err := a.DB.SQL.QueryRowContext(r.Context(), "insert into users(phone, password_hash) values($1, $2) returning id, email, phone, username, display_name, created_at", req.Phone, "otp").Scan(&u.ID, &u.Email, &u.Phone, &u.Username, &u.DisplayName, &u.CreatedAt)
		if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
	default:
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	tok, err := a.JWT.Sign(u.ID)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	a.RDB.Del(r.Context(), "otp:ph:"+req.Phone)
	writeJSON(w, http.StatusOK, TokenResp{Token: tok, User: u})
}

type ctxUserIDKey struct{}

func (a *App) authMiddleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ah := r.Header.Get("Authorization")
		if ah == "" || !strings.HasPrefix(ah, "Bearer ") {
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		tok := strings.TrimPrefix(ah, "Bearer ")
		claims, err := a.JWT.Parse(tok)
		if err != nil {
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		r = r.WithContext(context.WithValue(r.Context(), ctxUserIDKey{}, claims.UserID))
		next.ServeHTTP(w, r)
	}
}

func userIDFrom(ctx context.Context) (string, error) {
	v := ctx.Value(ctxUserIDKey{})
	if v == nil {
		return "", errors.New("no user")
	}
	id, ok := v.(string)
	if !ok || id == "" {
		return "", errors.New("no user")
	}
	return id, nil
}

func (a *App) handleWS(w http.ResponseWriter, r *http.Request) {
	tok := r.URL.Query().Get("token")
	if tok == "" {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	claims, err := a.JWT.Parse(tok)
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	c, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}
	wc := &wsConn{c: c}
	uid := claims.UserID
	a.Hub.Add(uid, wc)
	a.RDB.Set(r.Context(), "presence:"+uid, "online", time.Minute)
	defer func() { a.Hub.Remove(uid, wc); _ = wc.Close(); a.RDB.Set(r.Context(), "presence:"+uid, "offline", 0) }()
	for {
		_, msg, err := c.ReadMessage()
		if err != nil {
			return
		}
		_ = a.RDB.Set(r.Context(), "presence:"+uid, "online", time.Minute)
		var base struct {
			Op string `json:"op"`
		}
		if err := json.Unmarshal(msg, &base); err != nil {
			continue
		}
		if base.Op == "typing" {
			var t struct {
				Op       string `json:"op"`
				ToUserID string `json:"to_user_id"`
				Status   string `json:"status"`
			}
			if err := json.Unmarshal(msg, &t); err != nil {
				continue
			}
			if t.ToUserID == "" {
				continue
			}
			chatID, err := a.ensurePrivateChat(r.Context(), uid, t.ToUserID)
			if err != nil {
				continue
			}
			out := map[string]any{"event": "typing", "data": map[string]any{"from_user_id": uid, "to_user_id": t.ToUserID, "chat_id": chatID, "status": t.Status}}
			b, _ := json.Marshal(out)
			a.Hub.Broadcast(t.ToUserID, b)
			continue
		}
		if base.Op == "webrtc" {
			var wmsg struct {
				Op        string `json:"op"`
				Action    string `json:"action"`
				ToUserID  string `json:"to_user_id"`
				CallID    string `json:"call_id"`
				SDPType   string `json:"sdp_type"`
				SDP       string `json:"sdp"`
				Candidate any    `json:"candidate"`
			}
			if err := json.Unmarshal(msg, &wmsg); err != nil {
				continue
			}
			if wmsg.ToUserID == "" || wmsg.Action == "" {
				continue
			}
			_, err := a.ensurePrivateChat(r.Context(), uid, wmsg.ToUserID)
			if err != nil {
				continue
			}
			data := map[string]any{"from_user_id": uid, "to_user_id": wmsg.ToUserID, "call_id": wmsg.CallID, "action": wmsg.Action}
			if wmsg.SDP != "" {
				data["sdp_type"] = wmsg.SDPType
				data["sdp"] = wmsg.SDP
			}
			if wmsg.Candidate != nil {
				data["candidate"] = wmsg.Candidate
			}
			out := map[string]any{"event": "webrtc", "data": data}
			b, _ := json.Marshal(out)
			a.Hub.Broadcast(wmsg.ToUserID, b)
			continue
		}
		var in SendMessageReq
		if err := json.Unmarshal(msg, &in); err != nil {
			continue
		}
		if in.ChatID == "" && in.ToUserID == "" {
			continue
		}
		if len(in.Content) == 0 && len(in.Attachments) == 0 {
			continue
		}
		var chatID string
		if in.ChatID != "" {
			ok, role := a.isMember(r.Context(), in.ChatID, uid)
			if !ok {
				continue
			}
			if a.isChannel(r.Context(), in.ChatID) && role == "member" {
				continue
			}
			chatID = in.ChatID
		} else {
			var err error
			chatID, err = a.ensurePrivateChat(r.Context(), uid, in.ToUserID)
			if err != nil {
				continue
			}
		}
		payload := map[string]any{"type": in.Type, "content": in.Content}
		mr, err := a.insertMessage(r.Context(), chatID, uid, payload, in.Attachments)
		if err != nil {
			continue
		}
		out := map[string]any{"event": "message", "data": mr}
		b, _ := json.Marshal(out)
		if in.ChatID != "" {
			a.broadcastToChat(r.Context(), chatID, uid, b, mr)
		} else {
			a.Hub.Broadcast(uid, b)
			a.Hub.Broadcast(in.ToUserID, b)
		}
	}
}

func (a *App) ensurePrivateChat(ctx context.Context, uid1, uid2 string) (string, error) {
	if uid1 == uid2 {
		return "", errors.New("same user")
	}
	row := a.DB.SQL.QueryRowContext(ctx,
		"select c.id from chats c join chat_participants p1 on p1.chat_id=c.id and p1.user_id=$1 join chat_participants p2 on p2.chat_id=c.id and p2.user_id=$2 where c.kind='private' limit 1",
		uid1, uid2,
	)
	var id string
	switch err := row.Scan(&id); err {
	case nil:
		return id, nil
	case sql.ErrNoRows:
		if err := a.DB.SQL.QueryRowContext(ctx, "insert into chats(kind, meta) values('private', '{}'::jsonb) returning id").Scan(&id); err != nil {
			return "", err
		}
		if _, err := a.DB.SQL.ExecContext(ctx, "insert into chat_participants(chat_id,user_id) values($1,$2),($1,$3)", id, uid1, uid2); err != nil {
			return "", err
		}
		return id, nil
	default:
		return "", err
	}
}

func (a *App) insertMessage(ctx context.Context, chatID, senderID string, payload any, attachments []Attachment) (MessageResp, error) {
	b, _ := json.Marshal(payload)
	var attb []byte
	if attachments != nil {
		attb, _ = json.Marshal(attachments)
	}
	var mr MessageResp
	err := a.DB.SQL.QueryRowContext(ctx,
		"insert into messages(chat_id, sender_id, payload, attachments) values($1,$2,$3,$4) returning id, chat_id, sender_id, payload, attachments, created_at",
		chatID, senderID, string(b), string(attb),
	).Scan(&mr.ID, &mr.ChatID, &mr.SenderID, &mr.Payload, &mr.Attachments, &mr.CreatedAt)
	return mr, err
}

func (a *App) handleSendMessage(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	var req SendMessageReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if req.ChatID == "" && req.ToUserID == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if len(req.Content) == 0 && len(req.Attachments) == 0 {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	var chatID string
	if req.ChatID != "" {
		ok, role := a.isMember(r.Context(), req.ChatID, uid)
		if !ok {
			w.WriteHeader(http.StatusForbidden)
			return
		}
		if a.isChannel(r.Context(), req.ChatID) && role == "member" {
			w.WriteHeader(http.StatusForbidden)
			return
		}
		chatID = req.ChatID
	} else {
		var err error
		chatID, err = a.ensurePrivateChat(r.Context(), uid, req.ToUserID)
		if err != nil {
			w.WriteHeader(http.StatusBadRequest)
			return
		}
	}
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	payload := map[string]any{"type": req.Type, "content": req.Content}
	mr, err := a.insertMessage(r.Context(), chatID, uid, payload, req.Attachments)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	out := map[string]any{"event": "message", "data": mr}
	b, _ := json.Marshal(out)
	if req.ChatID != "" {
		a.broadcastToChat(r.Context(), chatID, uid, b, mr)
	} else {
		a.Hub.Broadcast(uid, b)
		a.Hub.Broadcast(req.ToUserID, b)
		if !a.Hub.Has(req.ToUserID) {
			a.pushNewMessage(r.Context(), req.ToUserID, uid, mr)
		}
	}
	writeJSON(w, http.StatusOK, mr)
}

func (a *App) handleGetWithUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	parts := strings.Split(strings.TrimPrefix(r.URL.Path, "/v1/messages/with/"), "/")
	if len(parts) < 1 || parts[0] == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	other := parts[0]
	limit := 50
	q := r.URL.Query().Get("limit")
	if q != "" {
		if n, err := strconv.Atoi(q); err == nil && n > 0 && n <= 200 {
			limit = n
		}
	}
	chatID, err := a.ensurePrivateChat(r.Context(), uid, other)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	w.Header().Set("X-Chat-ID", chatID)
	rows, err := a.DB.SQL.QueryContext(r.Context(), "select id, chat_id, sender_id, payload, attachments, created_at from messages where chat_id=$1 order by created_at desc limit $2", chatID, limit)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	var out []MessageResp
	for rows.Next() {
		var m MessageResp
		if err := rows.Scan(&m.ID, &m.ChatID, &m.SenderID, &m.Payload, &m.Attachments, &m.CreatedAt); err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		out = append(out, m)
	}
	writeJSON(w, http.StatusOK, out)
}

func (a *App) handleUploadInit(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	var req UploadInitReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if req.Filename == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	key := "u/" + uid + "/" + time.Now().Format("2006/01/02/") + strconv.FormatInt(time.Now().UnixNano(), 36) + "-" + sanitize(req.Filename)
	url, err := a.S3.PresignPut(r.Context(), key, 15*time.Minute)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	pub := url
	if a.CDNBase != "" {
		pub = a.CDNBase + "/" + key
	}
	writeJSON(w, http.StatusOK, UploadInitResp{URL: url, ObjectKey: key, Method: "PUT", ExpiresIn: 900, PublicURL: pub})
}

func (a *App) handleSearch(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	q := strings.TrimSpace(r.URL.Query().Get("q"))
	if q == "" {
		writeJSON(w, http.StatusOK, []MessageResp{})
		return
	}
	rows, err := a.DB.SQL.QueryContext(r.Context(),
		"select m.id, m.chat_id, m.sender_id, m.payload, m.attachments, m.created_at from messages m join chat_participants p on p.chat_id=m.chat_id where p.user_id=$1 and (m.payload->>'content') ilike $2 order by m.created_at desc limit 50",
		uid, "%"+q+"%",
	)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	var out []MessageResp
	for rows.Next() {
		var m MessageResp
		if err := rows.Scan(&m.ID, &m.ChatID, &m.SenderID, &m.Payload, &m.Attachments, &m.CreatedAt); err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		out = append(out, m)
	}
	writeJSON(w, http.StatusOK, out)
}

func sanitize(s string) string {
	s = strings.ReplaceAll(s, "\\", "-")
	s = strings.ReplaceAll(s, "/", "-")
	return s
}

func (a *App) handleMessagesByChat(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	chatID := strings.TrimPrefix(r.URL.Path, "/v1/messages/")
	chatID = strings.Split(chatID, "/")[0]
	ok, _ := a.isMember(r.Context(), chatID, uid)
	if !ok {
		w.WriteHeader(http.StatusForbidden)
		return
	}
	limit := 50
	if q := r.URL.Query().Get("limit"); q != "" {
		if n, err := strconv.Atoi(q); err == nil && n > 0 && n <= 200 {
			limit = n
		}
	}
	rows, err := a.DB.SQL.QueryContext(r.Context(), "select id, chat_id, sender_id, payload, attachments, created_at from messages where chat_id=$1 order by created_at desc limit $2", chatID, limit)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	var out []MessageResp
	for rows.Next() {
		var m MessageResp
		if err := rows.Scan(&m.ID, &m.ChatID, &m.SenderID, &m.Payload, &m.Attachments, &m.CreatedAt); err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		out = append(out, m)
	}
	writeJSON(w, http.StatusOK, out)
}

// Membership helpers and broadcasting

type ChatListItem struct {
	ChatID      string     `json:"chat_id"`
	Kind        string     `json:"kind"`
	Name        string     `json:"name"`
	OtherUserID *string    `json:"other_user_id,omitempty"`
	LastText    string     `json:"last_text"`
	LastAt      *time.Time `json:"last_at,omitempty"`
	Unread      int        `json:"unread"`
	Online      bool       `json:"online"`
}

func (a *App) isChannel(ctx context.Context, chatID string) bool {
	var kind string
	_ = a.DB.SQL.QueryRowContext(ctx, "select kind from chats where id=$1", chatID).Scan(&kind)
	return kind == "channel"
}

func (a *App) isMember(ctx context.Context, chatID, uid string) (bool, string) {
	var role string
	err := a.DB.SQL.QueryRowContext(ctx, "select role from chat_participants where chat_id=$1 and user_id=$2", chatID, uid).Scan(&role)
	if err != nil {
		return false, ""
	}
	return true, role
}

func (a *App) participants(ctx context.Context, chatID string) []string {
	rows, err := a.DB.SQL.QueryContext(ctx, "select user_id from chat_participants where chat_id=$1", chatID)
	if err != nil {
		return nil
	}
	defer rows.Close()
	var ids []string
	for rows.Next() {
		var id string
		_ = rows.Scan(&id)
		ids = append(ids, id)
	}
	return ids
}

func (a *App) broadcastToChat(ctx context.Context, chatID, exclude string, payload []byte, mr MessageResp) {
	ids := a.participants(ctx, chatID)
	for _, id := range ids {
		if id == exclude {
			continue
		}
		a.Hub.Broadcast(id, payload)
		if !a.Hub.Has(id) {
			a.pushNewMessage(ctx, id, exclude, mr)
		}
	}
}

func (a *App) handleChatsList(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	rows, err := a.DB.SQL.QueryContext(r.Context(), `
		select c.id, c.kind, coalesce(c.meta->>'title','') as name,
		  (select p2.user_id from chat_participants p2 where p2.chat_id=c.id and p2.user_id<>$1 limit 1) as other_id,
		  coalesce((select payload->>'content' from messages where chat_id=c.id order by id desc limit 1),'') as last_text,
		  (select created_at from messages where chat_id=c.id order by id desc limit 1) as last_at,
		  (select count(*) from messages where chat_id=c.id and id > coalesce(cp.last_read_msg_id,0)) as unread
		from chats c
		join chat_participants cp on cp.chat_id=c.id and cp.user_id=$1
		order by last_at desc nulls last
		limit 200`, uid)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	var out []ChatListItem
	for rows.Next() {
		var it ChatListItem
		var lastAt sql.NullTime
		var other sql.NullString
		if err := rows.Scan(&it.ChatID, &it.Kind, &it.Name, &other, &it.LastText, &lastAt, &it.Unread); err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		if other.Valid {
			s := other.String
			it.OtherUserID = &s
		}
		if lastAt.Valid {
			t := lastAt.Time
			it.LastAt = &t
		}
		if it.Kind == "private" && it.OtherUserID != nil {
			v, _ := a.RDB.Get(r.Context(), "presence:"+*it.OtherUserID).Result()
			it.Online = (v == "online")
		} else {
			it.Online = false
		}
		if it.Name == "" && it.Kind == "private" && it.OtherUserID != nil {
			it.Name = (*it.OtherUserID)
		}
		out = append(out, it)
	}
	writeJSON(w, http.StatusOK, out)
}

// Groups & Channels

type ChatCreateReq struct {
	Kind    string   `json:"kind"`
	Title   string   `json:"title"`
	Members []string `json:"members"`
}

func (a *App) handleCreateChat(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	var req ChatCreateReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if req.Kind != "group" && req.Kind != "channel" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	meta := map[string]any{"title": req.Title}
	mb, _ := json.Marshal(meta)
	var chatID string
	if err := a.DB.SQL.QueryRowContext(r.Context(), "insert into chats(kind, meta) values($1,$2) returning id", req.Kind, string(mb)).Scan(&chatID); err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	roleOwner := "owner"
	_, _ = a.DB.SQL.ExecContext(r.Context(), "insert into chat_participants(chat_id,user_id,role) values($1,$2,$3)", chatID, uid, roleOwner)
	for _, m := range req.Members {
		if m == uid {
			continue
		}
		_, _ = a.DB.SQL.ExecContext(r.Context(), "insert into chat_participants(chat_id,user_id,role) values($1,$2,'member') on conflict do nothing", chatID, m)
	}
	writeJSON(w, http.StatusOK, map[string]any{"chat_id": chatID})
}

type ParticipantsReq struct {
	Add    []string `json:"add"`
	Remove []string `json:"remove"`
}

type RolesReq struct {
	Promote []string `json:"promote"`
	Demote  []string `json:"demote"`
}

type UpdateChatReq struct {
	Title string `json:"title"`
}

type InviteCreateReq struct {
	ExpiresIn        int  `json:"expires_in"`
	MaxUses          *int `json:"max_uses"`
	RequiresApproval bool `json:"requires_approval"`
}

type InviteCreateResp struct {
	Code string `json:"code"`
	URL  string `json:"url"`
}

type JoinRequest struct {
	UserID    string    `json:"user_id"`
	Status    string    `json:"status"`
	CreatedAt time.Time `json:"created_at"`
}

func (a *App) handleParticipants(w http.ResponseWriter, r *http.Request) {
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	path := strings.TrimSuffix(strings.TrimPrefix(r.URL.Path, "/v1/chats/"), "/participants")
	chatID := strings.TrimSuffix(path, "/")
	if r.Method == http.MethodGet {
		rows, err := a.DB.SQL.QueryContext(r.Context(), "select user_id, role from chat_participants where chat_id=$1", chatID)
		if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		defer rows.Close()
		type P struct {
			UserID string `json:"user_id"`
			Role   string `json:"role"`
		}
		var out []P
		for rows.Next() {
			var p P
			_ = rows.Scan(&p.UserID, &p.Role)
			out = append(out, p)
		}
		writeJSON(w, http.StatusOK, out)
		return
	}
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	ok, role := a.isMember(r.Context(), chatID, uid)
	if !ok || (role != "owner" && role != "admin") {
		w.WriteHeader(http.StatusForbidden)
		return
	}
	var req ParticipantsReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	for _, u := range req.Add {
		if u != "" {
			_, _ = a.DB.SQL.ExecContext(r.Context(), "insert into chat_participants(chat_id,user_id,role) values($1,$2,'member') on conflict do nothing", chatID, u)
		}
	}
	for _, u := range req.Remove {
		if u != "" {
			_, _ = a.DB.SQL.ExecContext(r.Context(), "delete from chat_participants where chat_id=$1 and user_id=$2", chatID, u)
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

type WebSub struct {
	Endpoint string `json:"endpoint"`
	Keys     struct {
		P256dh string `json:"p256dh"`
		Auth   string `json:"auth"`
	} `json:"keys"`
}

func (a *App) handleUpdateChat(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPatch {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	chatID := strings.TrimPrefix(r.URL.Path, "/v1/chats/")
	ok, role := a.isMember(r.Context(), chatID, uid)
	if !ok || (role != "owner" && role != "admin") {
		w.WriteHeader(http.StatusForbidden)
		return
	}
	var req UpdateChatReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	meta := map[string]any{"title": req.Title}
	mb, _ := json.Marshal(meta)
	_, err = a.DB.SQL.ExecContext(r.Context(), "update chats set meta=$1 where id=$2", string(mb), chatID)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *App) handleRoles(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	chatID := strings.TrimSuffix(strings.TrimPrefix(r.URL.Path, "/v1/chats/"), "/roles")
	chatID = strings.TrimSuffix(chatID, "/")
	ok, role := a.isMember(r.Context(), chatID, uid)
	if !ok {
		w.WriteHeader(http.StatusForbidden)
		return
	}
	if role != "owner" {
		w.WriteHeader(http.StatusForbidden)
		return
	}
	var req RolesReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	for _, u := range req.Promote {
		if u != "" {
			_, _ = a.DB.SQL.ExecContext(r.Context(), "update chat_participants set role='admin' where chat_id=$1 and user_id=$2 and role<>'owner'", chatID, u)
		}
	}
	for _, u := range req.Demote {
		if u != "" {
			_, _ = a.DB.SQL.ExecContext(r.Context(), "update chat_participants set role='member' where chat_id=$1 and user_id=$2 and role<>'owner'", chatID, u)
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func randomCode(n int) string {
	const letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	b := make([]byte, n)
	for i := range b {
		b[i] = letters[int(time.Now().UnixNano()+int64(i))%len(letters)]
	}
	return string(b)
}

func (a *App) handleCreateInvite(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	chatID := strings.TrimSuffix(strings.TrimPrefix(r.URL.Path, "/v1/chats/"), "/invites")
	chatID = strings.TrimSuffix(chatID, "/")
	ok, role := a.isMember(r.Context(), chatID, uid)
	if !ok || (role != "owner" && role != "admin") {
		w.WriteHeader(http.StatusForbidden)
		return
	}
	var req InviteCreateReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	code := randomCode(12)
	var until *time.Time
	if req.ExpiresIn > 0 {
		t := time.Now().Add(time.Duration(req.ExpiresIn) * time.Second)
		until = &t
	}
	_, err = a.DB.SQL.ExecContext(r.Context(), "insert into chat_invite_links(chat_id, code, created_by, requires_approval, max_uses, expires_at) values($1,$2,$3,$4,$5,$6)", chatID, code, uid, req.RequiresApproval, req.MaxUses, until)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	url := code
	if a.AppBaseURL != "" {
		url = a.AppBaseURL + "/invite?code=" + code
	}
	writeJSON(w, http.StatusOK, InviteCreateResp{Code: code, URL: url})
}

func (a *App) handleInviteMux(w http.ResponseWriter, r *http.Request) {
	if strings.HasSuffix(r.URL.Path, "/join") {
		a.handleJoinInvite(w, r)
		return
	}
	w.WriteHeader(http.StatusNotFound)
}

func (a *App) handleJoinInvite(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	code := strings.TrimSuffix(strings.TrimPrefix(r.URL.Path, "/v1/invites/"), "/join")
	code = strings.TrimSuffix(code, "/")
	var chatID string
	var requires bool
	var maxUses sql.NullInt64
	var uses int
	var expires sql.NullTime
	err = a.DB.SQL.QueryRowContext(r.Context(), "select chat_id, requires_approval, max_uses, uses, expires_at from chat_invite_links where code=$1", code).Scan(&chatID, &requires, &maxUses, &uses, &expires)
	if err != nil {
		w.WriteHeader(http.StatusNotFound)
		return
	}
	if expires.Valid && time.Now().After(expires.Time) {
		w.WriteHeader(http.StatusGone)
		return
	}
	if maxUses.Valid && int64(uses) >= maxUses.Int64 {
		w.WriteHeader(http.StatusTooManyRequests)
		return
	}
	if requires {
		_, _ = a.DB.SQL.ExecContext(r.Context(), "insert into join_requests(chat_id, user_id, invite_code, status) values($1,$2,$3,'pending') on conflict (chat_id, user_id) do update set invite_code=excluded.invite_code, status='pending'", chatID, uid, code)
		writeJSON(w, http.StatusOK, map[string]any{"pending": true})
		return
	}
	_, _ = a.DB.SQL.ExecContext(r.Context(), "insert into chat_participants(chat_id,user_id,role) values($1,$2,'member') on conflict do nothing", chatID, uid)
	_, _ = a.DB.SQL.ExecContext(r.Context(), "update chat_invite_links set uses=uses+1 where code=$1", code)
	writeJSON(w, http.StatusOK, map[string]any{"joined": true})
}

func (a *App) handleListJoinRequests(w http.ResponseWriter, r *http.Request) {
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	chatID := strings.TrimSuffix(strings.TrimPrefix(r.URL.Path, "/v1/chats/"), "/join-requests")
	chatID = strings.TrimSuffix(chatID, "/")
	ok, role := a.isMember(r.Context(), chatID, uid)
	if !ok || (role != "owner" && role != "admin") {
		w.WriteHeader(http.StatusForbidden)
		return
	}
	rows, err := a.DB.SQL.QueryContext(r.Context(), "select user_id, status, created_at from join_requests where chat_id=$1 and status='pending' order by created_at asc", chatID)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	var out []JoinRequest
	for rows.Next() {
		var jr JoinRequest
		_ = rows.Scan(&jr.UserID, &jr.Status, &jr.CreatedAt)
		out = append(out, jr)
	}
	writeJSON(w, http.StatusOK, out)
}

func (a *App) handleActOnJoinRequest(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/v1/chats/")
	parts := strings.Split(path, "/")
	if len(parts) < 3 || parts[1] != "join-requests" {
		w.WriteHeader(http.StatusNotFound)
		return
	}
	chatID := parts[0]
	targetUser := parts[2]
	ok, role := a.isMember(r.Context(), chatID, uid)
	if !ok || (role != "owner" && role != "admin") {
		w.WriteHeader(http.StatusForbidden)
		return
	}
	var b struct {
		Action string `json:"action"`
	}
	if err := json.NewDecoder(r.Body).Decode(&b); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	switch b.Action {
	case "approve":
		_, _ = a.DB.SQL.ExecContext(r.Context(), "update join_requests set status='approved' where chat_id=$1 and user_id=$2", chatID, targetUser)
		_, _ = a.DB.SQL.ExecContext(r.Context(), "insert into chat_participants(chat_id,user_id,role) values($1,$2,'member') on conflict do nothing", chatID, targetUser)
		_, _ = a.DB.SQL.ExecContext(r.Context(), "update chat_invite_links set uses=uses+1 where code in (select invite_code from join_requests where chat_id=$1 and user_id=$2)", chatID, targetUser)
	case "reject":
		_, _ = a.DB.SQL.ExecContext(r.Context(), "update join_requests set status='rejected' where chat_id=$1 and user_id=$2", chatID, targetUser)
	default:
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

type FCMRegisterReq struct {
	Token    string `json:"token"`
	Platform string `json:"platform"`
	DeviceID string `json:"device_id"`
}

type E2EKeyRegisterReq struct {
	IdentityKey    string `json:"identity_key"`
	RegistrationID int    `json:"registration_id"`
	SignedPreKey   struct {
		KeyID     int    `json:"key_id"`
		PublicKey string `json:"public_key"`
		Signature string `json:"signature"`
	} `json:"signed_prekey"`
	PreKeys []struct {
		KeyID     int    `json:"key_id"`
		PublicKey string `json:"public_key"`
	} `json:"prekeys"`
}

type E2EBundleResp struct {
	IdentityKey    string `json:"identity_key"`
	RegistrationID int    `json:"registration_id"`
	SignedPreKey   struct {
		KeyID     int    `json:"key_id"`
		PublicKey string `json:"public_key"`
		Signature string `json:"signature"`
	} `json:"signed_prekey"`
	PreKey *struct {
		KeyID     int    `json:"key_id"`
		PublicKey string `json:"public_key"`
	} `json:"prekey,omitempty"`
}

func (a *App) handleVAPIDPublic(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"key": a.VAPIDPublic})
}

func (a *App) handleRegisterWebPush(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	var sub WebSub
	if err := json.NewDecoder(r.Body).Decode(&sub); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if sub.Endpoint == "" || sub.Keys.P256dh == "" || sub.Keys.Auth == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	_, err = a.DB.SQL.ExecContext(r.Context(), "insert into web_push_subscriptions(user_id, endpoint, p256dh, auth) values($1,$2,$3,$4) on conflict (endpoint) do update set user_id=excluded.user_id, p256dh=excluded.p256dh, auth=excluded.auth", uid, sub.Endpoint, sub.Keys.P256dh, sub.Keys.Auth)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *App) handleRegisterFCM(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	var req FCMRegisterReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if req.Token == "" || req.Platform == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	_, err = a.DB.SQL.ExecContext(r.Context(), "insert into device_tokens(user_id, token, platform, device_id, last_seen) values($1,$2,$3,$4, now()) on conflict (token) do update set user_id=excluded.user_id, platform=excluded.platform, device_id=excluded.device_id, last_seen=now()", uid, req.Token, req.Platform, req.DeviceID)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *App) handleE2ERegister(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	var req E2EKeyRegisterReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if req.IdentityKey == "" || req.RegistrationID == 0 || req.SignedPreKey.PublicKey == "" || req.SignedPreKey.Signature == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	_, err = a.DB.SQL.ExecContext(r.Context(), "insert into user_e2e_keys(user_id, identity_key, registration_id, spk_id, spk_pub, spk_sig) values($1,$2,$3,$4,$5,$6) on conflict (user_id) do update set identity_key=excluded.identity_key, registration_id=excluded.registration_id, spk_id=excluded.spk_id, spk_pub=excluded.spk_pub, spk_sig=excluded.spk_sig", uid, req.IdentityKey, req.RegistrationID, req.SignedPreKey.KeyID, req.SignedPreKey.PublicKey, req.SignedPreKey.Signature)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	_, _ = a.DB.SQL.ExecContext(r.Context(), "delete from user_e2e_one_time_prekeys where user_id=$1", uid)
	for _, pk := range req.PreKeys {
		if pk.KeyID == 0 || pk.PublicKey == "" {
			continue
		}
		_, _ = a.DB.SQL.ExecContext(r.Context(), "insert into user_e2e_one_time_prekeys(user_id, key_id, pub, used) values($1,$2,$3,false) on conflict do nothing", uid, pk.KeyID, pk.PublicKey)
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *App) handleE2EBundle(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	_, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/v1/e2e/bundle/")
	target := strings.TrimSuffix(path, "/")
	if target == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	var out E2EBundleResp
	err = a.DB.SQL.QueryRowContext(r.Context(), "select identity_key, registration_id, spk_id, spk_pub, spk_sig from user_e2e_keys where user_id=$1", target).Scan(&out.IdentityKey, &out.RegistrationID, &out.SignedPreKey.KeyID, &out.SignedPreKey.PublicKey, &out.SignedPreKey.Signature)
	if err != nil {
		w.WriteHeader(http.StatusNotFound)
		return
	}
	// pop one-time prekey if available
	var pkid int
	var pkpub string
	tx, txerr := a.DB.SQL.BeginTx(r.Context(), nil)
	if txerr == nil {
		row := tx.QueryRowContext(r.Context(), "select key_id, pub from user_e2e_one_time_prekeys where user_id=$1 and used=false order by key_id asc limit 1 for update", target)
		scanErr := row.Scan(&pkid, &pkpub)
		if scanErr == nil {
			_, _ = tx.ExecContext(r.Context(), "update user_e2e_one_time_prekeys set used=true where user_id=$1 and key_id=$2", target, pkid)
			_ = tx.Commit()
			out.PreKey = &struct {
				KeyID     int    `json:"key_id"`
				PublicKey string `json:"public_key"`
			}{KeyID: pkid, PublicKey: pkpub}
		} else {
			_ = tx.Rollback()
		}
	}
	writeJSON(w, http.StatusOK, out)
}

func (a *App) handlePushTest(w http.ResponseWriter, r *http.Request) {
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	a.pushNewMessage(r.Context(), uid, uid, MessageResp{Payload: map[string]any{"type": "text", "content": "Test"}})
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

// Reactions & Forwarding

type ReactReq struct {
	Emoji string `json:"emoji"`
}

func (a *App) handleReact(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	idStr := strings.TrimPrefix(r.URL.Path, "/v1/messages/react/")
	mid, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	var req ReactReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if req.Emoji == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	var chatID string
	if err := a.DB.SQL.QueryRowContext(r.Context(), "select chat_id from messages where id=$1", mid).Scan(&chatID); err != nil {
		w.WriteHeader(http.StatusNotFound)
		return
	}
	ok, _ := a.isMember(r.Context(), chatID, uid)
	if !ok {
		w.WriteHeader(http.StatusForbidden)
		return
	}
	res, _ := a.DB.SQL.ExecContext(r.Context(), "delete from message_reactions where message_id=$1 and user_id=$2 and emoji=$3", mid, uid, req.Emoji)
	aff, _ := res.RowsAffected()
	if aff == 0 {
		_, _ = a.DB.SQL.ExecContext(r.Context(), "insert into message_reactions(message_id,user_id,emoji) values($1,$2,$3) on conflict do nothing", mid, uid, req.Emoji)
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

type ReactionsOut struct {
	MessageID int64          `json:"message_id"`
	Counts    map[string]int `json:"counts"`
}

func (a *App) handleReactionsForChat(w http.ResponseWriter, r *http.Request) {
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	chatID := r.URL.Query().Get("chat_id")
	if chatID == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	ok, _ := a.isMember(r.Context(), chatID, uid)
	if !ok {
		w.WriteHeader(http.StatusForbidden)
		return
	}
	rows, err := a.DB.SQL.QueryContext(r.Context(), `
		select message_id, emoji, count(*) from message_reactions where message_id in (select id from messages where chat_id=$1 order by id desc limit 200) group by message_id, emoji`, chatID)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	m := map[int64]map[string]int{}
	for rows.Next() {
		var mid int64
		var emoji string
		var cnt int
		_ = rows.Scan(&mid, &emoji, &cnt)
		if m[mid] == nil {
			m[mid] = map[string]int{}
		}
		m[mid][emoji] = cnt
	}
	var out []ReactionsOut
	for k, v := range m {
		out = append(out, ReactionsOut{MessageID: k, Counts: v})
	}
	writeJSON(w, http.StatusOK, out)
}

type ForwardReq struct {
	ToUserID string `json:"to_user_id"`
	ChatID   string `json:"chat_id"`
}

func (a *App) handleForward(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	idStr := strings.TrimPrefix(r.URL.Path, "/v1/messages/forward/")
	mid, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	var req ForwardReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	var orig MessageResp
	if err := a.DB.SQL.QueryRowContext(r.Context(), "select id, chat_id, sender_id, payload, attachments, created_at from messages where id=$1", mid).Scan(&orig.ID, &orig.ChatID, &orig.SenderID, &orig.Payload, &orig.Attachments, &orig.CreatedAt); err != nil {
		w.WriteHeader(http.StatusNotFound)
		return
	}
	var targetChat string
	if req.ChatID != "" {
		ok, role := a.isMember(r.Context(), req.ChatID, uid)
		if !ok {
			w.WriteHeader(http.StatusForbidden)
			return
		}
		if a.isChannel(r.Context(), req.ChatID) && role == "member" {
			w.WriteHeader(http.StatusForbidden)
			return
		}
		targetChat = req.ChatID
	} else if req.ToUserID != "" {
		var err error
		targetChat, err = a.ensurePrivateChat(r.Context(), uid, req.ToUserID)
		if err != nil {
			w.WriteHeader(http.StatusBadRequest)
			return
		}
	} else {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	payload := map[string]any{"type": "forward", "content": "", "forward": map[string]any{"from_chat_id": orig.ChatID, "from_message_id": orig.ID, "from_sender_id": orig.SenderID}, "orig": orig.Payload}
	mr, err := a.insertMessage(r.Context(), targetChat, uid, payload, orig.Attachments)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	out := map[string]any{"event": "message", "data": mr}
	b, _ := json.Marshal(out)
	a.broadcastToChat(r.Context(), targetChat, uid, b, mr)
	writeJSON(w, http.StatusOK, mr)
}

func (a *App) pushNewMessage(ctx context.Context, toUserID, fromUserID string, m MessageResp) {
	title := "New message"
	if len(fromUserID) > 0 {
		title = "New message"
	}
	body := "You have a new message"
	if p, ok := m.Payload.(map[string]any); ok {
		if c, ok := p["content"].(string); ok && c != "" {
			body = c
		}
	}
	if a.VAPIDPublic != "" && a.VAPIDPrivate != "" {
		rows, _ := a.DB.SQL.QueryContext(ctx, "select endpoint, p256dh, auth from web_push_subscriptions where user_id=$1", toUserID)
		for rows != nil && rows.Next() {
			var endpoint, p256dh, authk string
			_ = rows.Scan(&endpoint, &p256dh, &authk)
			sub := push.WebSubscription{Endpoint: endpoint}
			sub.Keys.P256dh = p256dh
			sub.Keys.Auth = authk
			click := ""
			if a.AppBaseURL != "" {
				click = a.AppBaseURL + "?from=" + fromUserID + "&chat_id=" + m.ChatID
			}
			_ = push.WebPushSender{PublicKey: a.VAPIDPublic, PrivateKey: a.VAPIDPrivate, Subject: a.VAPIDSubject}.Send(ctx, sub, push.NotificationPayload{Title: title, Body: body, ClickURL: click})
		}
		if rows != nil {
			rows.Close()
		}
	}
	if a.FCMKey != "" {
		rows, _ := a.DB.SQL.QueryContext(ctx, "select token from device_tokens where user_id=$1", toUserID)
		for rows != nil && rows.Next() {
			var t string
			_ = rows.Scan(&t)
			click := ""
			if a.AppBaseURL != "" {
				click = a.AppBaseURL + "?from=" + fromUserID + "&chat_id=" + m.ChatID
			}
			_ = push.FCMSender{ServerKey: a.FCMKey}.SendToToken(ctx, t, push.FCMMessage{Title: title, Body: body, Data: map[string]string{"chat_id": m.ChatID, "from_user_id": fromUserID, "click_url": click}})
		}
		if rows != nil {
			rows.Close()
		}
	}
}

// Users search
func (a *App) handleUsersSearch(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	_, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	q := strings.TrimSpace(r.URL.Query().Get("q"))
	if q == "" {
		writeJSON(w, http.StatusOK, []map[string]any{})
		return
	}
	rows, err := a.DB.SQL.QueryContext(r.Context(), "select id, username, display_name from users where (username ilike $1 or display_name ilike $1) order by username asc limit 20", "%"+q+"%")
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var id, username, displayName sql.NullString
		_ = rows.Scan(&id, &username, &displayName)
		m := map[string]any{"id": id.String}
		if username.Valid {
			m["username"] = username.String
		}
		if displayName.Valid {
			m["display_name"] = displayName.String
		}
		out = append(out, m)
	}
	writeJSON(w, http.StatusOK, out)
}

// Statuses (Stories)

type StatusCreateReq struct {
	Type        string       `json:"type"`
	Content     string       `json:"content"`
	Attachments []Attachment `json:"attachments"`
}

type StatusResp struct {
	ID          int64        `json:"id"`
	UserID      string       `json:"user_id"`
	Payload     any          `json:"payload"`
	Attachments []Attachment `json:"attachments"`
	CreatedAt   time.Time    `json:"created_at"`
	ExpiresAt   time.Time    `json:"expires_at"`
	Viewed      bool         `json:"viewed"`
}

func (a *App) handleCreateStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	var req StatusCreateReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	if req.Type == "" && req.Content != "" {
		req.Type = "text"
	}
	if req.Type == "" && len(req.Attachments) > 0 {
		req.Type = "media"
	}
	if req.Type == "" {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	payload := map[string]any{"type": req.Type, "content": req.Content}
	attb, _ := json.Marshal(req.Attachments)
	pb, _ := json.Marshal(payload)
	exp := time.Now().Add(24 * time.Hour)
	var out StatusResp
	err = a.DB.SQL.QueryRowContext(r.Context(), "insert into statuses(user_id, payload, attachments, expires_at) values($1,$2,$3,$4) returning id, user_id, payload, attachments, created_at, expires_at", uid, string(pb), string(attb), exp).Scan(&out.ID, &out.UserID, &out.Payload, &out.Attachments, &out.CreatedAt, &out.ExpiresAt)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	out.Viewed = true
	writeJSON(w, http.StatusOK, out)
}

func (a *App) handleStatusFeed(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	rows, err := a.DB.SQL.QueryContext(r.Context(), `
		select s.id, s.user_id, s.payload, s.attachments, s.created_at, s.expires_at,
		  exists(select 1 from status_views v where v.status_id=s.id and v.viewer_id=$1) as viewed
		from statuses s
		where s.expires_at > now()
		  and s.user_id in (
		    select p2.user_id from chat_participants p1
		    join chat_participants p2 on p1.chat_id=p2.chat_id and p2.user_id<>p1.user_id
		    join chats c on c.id=p1.chat_id and c.kind='private'
		    where p1.user_id=$1
		  )
		order by s.created_at desc
		limit 100`, uid)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	var out []StatusResp
	for rows.Next() {
		var s StatusResp
		if err := rows.Scan(&s.ID, &s.UserID, &s.Payload, &s.Attachments, &s.CreatedAt, &s.ExpiresAt, &s.Viewed); err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		out = append(out, s)
	}
	writeJSON(w, http.StatusOK, out)
}

func (a *App) handleStatusView(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	uid, err := userIDFrom(r.Context())
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	idStr := strings.TrimPrefix(r.URL.Path, "/v1/status/view/")
	idStr = strings.TrimSuffix(idStr, "/")
	mid, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	_, _ = a.DB.SQL.ExecContext(r.Context(), "insert into status_views(status_id, viewer_id) values($1,$2) on conflict do nothing", mid, uid)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

// Chat path multiplexer
func (a *App) handleChatMux(w http.ResponseWriter, r *http.Request) {
	p := r.URL.Path
	if strings.Contains(p, "/participants") {
		a.handleParticipants(w, r)
		return
	}
	if strings.Contains(p, "/roles") {
		a.handleRoles(w, r)
		return
	}
	if strings.Contains(p, "/join-requests") {
		if r.Method == http.MethodGet && strings.HasSuffix(p, "/join-requests") {
			a.handleListJoinRequests(w, r)
		} else {
			a.handleActOnJoinRequest(w, r)
		}
		return
	}
	if r.Method == http.MethodPatch {
		a.handleUpdateChat(w, r)
		return
	}
	w.WriteHeader(http.StatusNotFound)
}

package main

import (
	"fmt"
	webpush "github.com/SherClockHolmes/webpush-go"
)

func main() {
	pub, priv, err := webpush.GenerateVAPIDKeys()
	if err != nil {
		fmt.Println("ERR:", err.Error())
		return
	}
	fmt.Println("PUB:", pub)
	fmt.Println("PRIV:", priv)
}

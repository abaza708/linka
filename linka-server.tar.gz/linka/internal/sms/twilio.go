package sms

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/url"
)

type Twilio struct {
	AccountSID string
	AuthToken  string
	From       string
}

type twilioResp struct{ SID string `json:"sid"` }

func (t Twilio) SendSMS(to, body string) error {
	if t.AccountSID == "" || t.AuthToken == "" || t.From == "" { return nil }
	u := "https://api.twilio.com/2010-04-01/Accounts/" + t.AccountSID + "/Messages.json"
	v := url.Values{}
	v.Set("To", to)
	v.Set("From", t.From)
	v.Set("Body", body)
	req, _ := http.NewRequest(http.MethodPost, u, bytes.NewBufferString(v.Encode()))
	req.SetBasicAuth(t.AccountSID, t.AuthToken)
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	resp, err := http.DefaultClient.Do(req)
	if err != nil { return err }
	defer resp.Body.Close()
	if resp.StatusCode >= 300 { return json.NewDecoder(resp.Body).Decode(&twilioResp{}) }
	return nil
}

package db

import (
	"context"
	"database/sql"
	"embed"
	"strings"

	_ "github.com/jackc/pgx/v5/stdlib"
)

//go:embed migrations.sql
var migrationsFS embed.FS

type DB struct {
	SQL *sql.DB
}

func Connect(dsn string) (*DB, error) {
	db, err := sql.Open("pgx", dsn)
	if err != nil {
		return nil, err
	}
	if err := db.Ping(); err != nil {
		return nil, err
	}
	return &DB{SQL: db}, nil
}

func (d *DB) Close() error {
	return d.SQL.Close()
}

func (d *DB) Migrate(ctx context.Context) error {
	b, err := migrationsFS.ReadFile("migrations.sql")
	if err != nil {
		return err
	}
	stmts := strings.Split(string(b), ";\n")
	for _, s := range stmts {
		s = strings.TrimSpace(s)
		if s == "" {
			continue
		}
		if _, err := d.SQL.ExecContext(ctx, s); err != nil {
			return err
		}
	}
	return nil
}

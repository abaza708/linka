create extension if not exists pgcrypto;

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text unique,
  phone text unique,
  username text unique,
  display_name text,
  password_hash text not null,
  created_at timestamptz not null default now()
);

create table if not exists chats (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('private','group','channel')),
  meta jsonb,
  created_at timestamptz not null default now()
);

create table if not exists chat_participants (
  chat_id uuid not null references chats(id) on delete cascade,
  user_id uuid not null references users(id) on delete cascade,
  primary key (chat_id, user_id)
);

create table if not exists messages (
  id bigserial primary key,
  chat_id uuid not null references chats(id) on delete cascade,
  sender_id uuid not null references users(id) on delete cascade,
  payload jsonb not null,
  attachments jsonb,
  created_at timestamptz not null default now(),
  deleted_at timestamptz
);

create index if not exists idx_messages_chat_id_created_at on messages(chat_id, created_at desc);

create table if not exists web_push_subscriptions (
  id bigserial primary key,
  user_id uuid not null references users(id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  created_at timestamptz not null default now()
);

create table if not exists device_tokens (
  id bigserial primary key,
  user_id uuid not null references users(id) on delete cascade,
  token text not null unique,
  platform text not null,
  device_id text,
  created_at timestamptz not null default now(),
  last_seen timestamptz
);

alter table chat_participants add column if not exists last_read_msg_id bigint default 0;
alter table chat_participants add column if not exists role text not null default 'member' check (role in ('owner','admin','member'));

create table if not exists message_reactions (
  message_id bigint not null references messages(id) on delete cascade,
  user_id uuid not null references users(id) on delete cascade,
  emoji text not null,
  created_at timestamptz not null default now(),
  primary key (message_id, user_id, emoji)
);
create index if not exists idx_message_reactions_msg on message_reactions(message_id);

create table if not exists chat_invite_links (
  id bigserial primary key,
  chat_id uuid not null references chats(id) on delete cascade,
  code text not null unique,
  created_by uuid not null references users(id) on delete cascade,
  requires_approval boolean not null default false,
  max_uses int,
  uses int not null default 0,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists idx_invite_chat on chat_invite_links(chat_id);

create table if not exists join_requests (
  id bigserial primary key,
  chat_id uuid not null references chats(id) on delete cascade,
  user_id uuid not null references users(id) on delete cascade,
  invite_code text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  unique(chat_id, user_id)  -- one active request per user per chat
);

create index if not exists idx_users_username_lower on users ((lower(username)));

-- Statuses (Stories)
create table if not exists statuses (
  id bigserial primary key,
  user_id uuid not null references users(id) on delete cascade,
  payload jsonb not null,
  attachments jsonb,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index if not exists idx_statuses_user_expires on statuses(user_id, expires_at);
create index if not exists idx_statuses_expires on statuses(expires_at);

create table if not exists status_views (
  status_id bigint not null references statuses(id) on delete cascade,
  viewer_id uuid not null references users(id) on delete cascade,
  viewed_at timestamptz not null default now(),
  primary key (status_id, viewer_id)
);

-- E2E keys (Signal-style)
create table if not exists user_e2e_keys (
  user_id uuid primary key references users(id) on delete cascade,
  identity_key text not null,
  registration_id int not null,
  spk_id int not null,
  spk_pub text not null,
  spk_sig text not null,
  created_at timestamptz not null default now()
);

create table if not exists user_e2e_one_time_prekeys (
  user_id uuid not null references users(id) on delete cascade,
  key_id int not null,
  pub text not null,
  used boolean not null default false,
  created_at timestamptz not null default now(),
  primary key (user_id, key_id)
);

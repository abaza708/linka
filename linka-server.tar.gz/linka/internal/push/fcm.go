package push

import (
	"context"
	"encoding/json"

	fcm "github.com/appleboy/go-fcm"
)

type FCMSender struct{ ServerKey string }

type FCMMessage struct{
	Title string
	Body string
	Data map[string]string
}

func (s FCMSender) SendToToken(ctx context.Context, token string, msg FCMMessage) error {
	c, err := fcm.NewClient(s.ServerKey)
	if err != nil { return err }
	m := &fcm.Message{To: token, Notification: &fcm.Notification{Title: msg.Title, Body: msg.Body}, Data: map[string]interface{}{}, ContentAvailable: true}
	for k, v := range msg.Data { m.Data[k] = v }
	_, err = c.SendWithContext(ctx, m)
	return err
}

func (s FCMSender) SendDataToToken(ctx context.Context, token string, data map[string]any) error {
	c, err := fcm.NewClient(s.ServerKey)
	if err != nil { return err }
	m := &fcm.Message{To: token, Data: map[string]interface{}{}, ContentAvailable: true}
	for k, v := range data {
		b, _ := json.Marshal(v)
		m.Data[k] = string(b)
	}
	_, err = c.SendWithContext(ctx, m)
	return err
}

package push

import (
	"context"
	"encoding/json"

	webpush "github.com/SherClockHolmes/webpush-go"
)

type WebPushSender struct{
	PublicKey string
	PrivateKey string
	Subject string
}

type WebSubscription struct{
	Endpoint string `json:"endpoint"`
	Keys struct{
		P256dh string `json:"p256dh"`
		Auth string `json:"auth"`
	} `json:"keys"`
}

type NotificationPayload struct{
	Title string `json:"title"`
	Body string `json:"body"`
	Icon string `json:"icon,omitempty"`
	Badge string `json:"badge,omitempty"`
	ClickURL string `json:"click_url,omitempty"`
}

func (s WebPushSender) Send(ctx context.Context, sub WebSubscription, payload NotificationPayload) error {
	b, _ := json.Marshal(map[string]any{"notification": map[string]any{"title": payload.Title, "body": payload.Body, "icon": payload.Icon, "badge": payload.Badge, "data": map[string]any{"url": payload.ClickURL}}})
	_, err := webpush.SendNotificationWithContext(ctx, b, &webpush.Subscription{Endpoint: sub.Endpoint, Keys: webpush.Keys{P256dh: sub.Keys.P256dh, Auth: sub.Keys.Auth}}, &webpush.Options{Subscriber: s.Subject, VAPIDPublicKey: s.PublicKey, VAPIDPrivateKey: s.PrivateKey, TTL: 60})
	return err
}

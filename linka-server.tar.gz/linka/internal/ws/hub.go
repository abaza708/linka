package ws

import (
	"sync"
)

type Hub struct {
	mu      sync.RWMutex
	clients map[string]map[Conn]struct{}
}

type Conn interface{
	Send([]byte) error
	Close() error
}

func NewHub() *Hub {
	return &Hub{clients: make(map[string]map[Conn]struct{})}
}

func (h *Hub) Add(userID string, c Conn) {
	h.mu.Lock()
	defer h.mu.Unlock()
	m, ok := h.clients[userID]
	if !ok {
		m = make(map[Conn]struct{})
		h.clients[userID] = m
	}
	m[c] = struct{}{}
}

func (h *Hub) Remove(userID string, c Conn) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if m, ok := h.clients[userID]; ok {
		delete(m, c)
		if len(m) == 0 {
			delete(h.clients, userID)
		}
	}
}

func (h *Hub) Broadcast(userID string, payload []byte) {
	h.mu.RLock()
	m := h.clients[userID]
	h.mu.RUnlock()
	for c := range m {
		_ = c.Send(payload)
	}
}

func (h *Hub) Has(userID string) bool {
	h.mu.RLock()
	defer h.mu.RUnlock()
	m, ok := h.clients[userID]
	return ok && len(m) > 0
}

package storage

import (
	"context"
	"time"

	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
)

type S3 struct {
	Client *minio.Client
	Bucket string
}

func Connect(endpoint, accessKey, secretKey string, secure bool, bucket string) (*S3, error) {
	c, err := minio.New(endpoint, &minio.Options{Creds: credentials.NewStaticV4(accessKey, secretKey, ""), Secure: secure})
	if err != nil { return nil, err }
	s := &S3{Client: c, Bucket: bucket}
	ctx := context.Background()
	exists, err := c.BucketExists(ctx, bucket)
	if err != nil { return nil, err }
	if !exists { if err := c.MakeBucket(ctx, bucket, minio.MakeBucketOptions{}); err != nil { return nil, err } }
	return s, nil
}

func (s *S3) PresignPut(ctx context.Context, objectName string, expiry time.Duration) (string, error) {
	u, err := s.Client.PresignedPutObject(ctx, s.Bucket, objectName, expiry)
	if err != nil { return "", err }
	return u.String(), nil
}

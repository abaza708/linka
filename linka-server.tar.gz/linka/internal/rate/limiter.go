package rate

import (
	"context"
	"time"

	"github.com/redis/go-redis/v9"
)

type Limiter struct { RDB *redis.Client }

func (l Limiter) Allow(ctx context.Context, key string, limit int, window time.Duration) bool {
	c, err := l.RDB.Incr(ctx, key).Result()
	if err != nil { return false }
	if c == 1 { l.RDB.Expire(ctx, key, window) }
	return int(c) <= limit
}
